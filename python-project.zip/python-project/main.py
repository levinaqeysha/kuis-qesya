nama = input("Masukkan nama mahasiswa: ").strip().lower()

if nama == "andi":
    target = 70
elif nama == "budi":
    target = 75
elif nama == "citra":
    target = 80
else:
    print("Nama mahasiswa tidak terdaftar")
    exit()

print("Target nilai:", target)

percobaan = 1
lulus = False

while percobaan <= 3:
    nilai = int(input("Masukkan nilai ujian ke-" + str(percobaan) + ": "))

    if nilai >= target:
        lulus = True
        break
    else:
        print("Nilai belum mencapai target.")
    
    percobaan += 1

if lulus:
    print(nama, "berhasil lulus setelah", percobaan, "kali percobaan!")
else:
    print(nama, "berhasil lulus setelah 3 kali percobaan.")
